declare class AssetUtil {
    get GFXToValueTypeMap(): any;
    getDefaultValue(type: string, data?: any): any;
}
declare const _default: AssetUtil;
export default _default;
//# sourceMappingURL=utils.d.ts.map