import IconGizmoBase from './icon-gizmo-base';
declare class SpotLightIconGizmo extends IconGizmoBase {
    createController(): void;
    updateController(): void;
}
export default SpotLightIconGizmo;
//# sourceMappingURL=spot-light-icon-gizmo.d.ts.map