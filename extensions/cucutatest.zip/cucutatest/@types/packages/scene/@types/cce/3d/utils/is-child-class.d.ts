declare const _default: (subClass: any, ...superClasses: any) => any;
export default _default;
//# sourceMappingURL=is-child-class.d.ts.map