import Joint2DGizmo from './joint-2d-gizmo';
declare class RelativeJoint2DGizmo extends Joint2DGizmo {
}
export default RelativeJoint2DGizmo;
//# sourceMappingURL=relative-joint-2d-gizmo.d.ts.map