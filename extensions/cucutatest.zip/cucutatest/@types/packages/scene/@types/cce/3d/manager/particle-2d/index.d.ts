export declare class Particle2DManager {
    exportParticlePlist(compId: any): Promise<any>;
    _applyPlistData(data: any, target: any): any;
}
declare const _default: Particle2DManager;
export default _default;
//# sourceMappingURL=index.d.ts.map