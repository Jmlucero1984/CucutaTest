import GizmoBase from '../../gizmo-base';
declare class PlaneColliderGizmo extends GizmoBase {
    private _controller;
    init(): void;
    onShow(): void;
    onHide(): void;
    updateControllerData(): void;
    onTargetUpdate(): void;
    onNodeChanged(): void;
}
export default PlaneColliderGizmo;
//# sourceMappingURL=plane-collider-gizmo.d.ts.map